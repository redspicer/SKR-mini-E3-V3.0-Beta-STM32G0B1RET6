#
# mks_robin_nano.py
#
import robin
robin.prepare("0x08007000", "mks_robin_nano.ld", "Robin_nano.bin")
